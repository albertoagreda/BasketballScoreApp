package com.example.basketballscoreapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.basketballscoreapp.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    // Constantes para pasar datos
    public static final String EXTRA_LOCAL_SCORE = "extra_local_score";
    public static final String EXTRA_VISITOR_SCORE = "extra_visitor_score";

    // Data Binding
    private ActivityMainBinding binding;

    // Variables para los marcadores
    private int localScore = 0;
    private int visitorScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializar Data Binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Configurar listeners para equipo Local
        binding.btnLocalPlusOne.setOnClickListener(v -> addLocalPoints(1));
        binding.btnLocalPlusTwo.setOnClickListener(v -> addLocalPoints(2));
        binding.btnLocalMinusOne.setOnClickListener(v -> subtractLocalPoints(1));

        // Configurar listeners para equipo Visitante
        binding.btnVisitorPlusOne.setOnClickListener(v -> addVisitorPoints(1));
        binding.btnVisitorPlusTwo.setOnClickListener(v -> addVisitorPoints(2));
        binding.btnVisitorMinusOne.setOnClickListener(v -> subtractVisitorPoints(1));

        // Botón Reset
        binding.btnReset.setOnClickListener(v -> resetScores());

        // Botón Resultados
        binding.btnShowResults.setOnClickListener(v -> showResults());
    }

    // Métodos para equipo Local
    private void addLocalPoints(int points) {
        localScore += points;
        updateLocalScore();
    }

    private void subtractLocalPoints(int points) {
        if (localScore > 0) {
            localScore -= points;
            if (localScore < 0) {
                localScore = 0;
            }
            updateLocalScore();
        }
    }

    private void updateLocalScore() {
        binding.tvLocalScore.setText(String.valueOf(localScore));
    }

    // Métodos para equipo Visitante
    private void addVisitorPoints(int points) {
        visitorScore += points;
        updateVisitorScore();
    }

    private void subtractVisitorPoints(int points) {
        if (visitorScore > 0) {
            visitorScore -= points;
            if (visitorScore < 0) {
                visitorScore = 0;
            }
            updateVisitorScore();
        }
    }

    private void updateVisitorScore() {
        binding.tvVisitorScore.setText(String.valueOf(visitorScore));
    }

    // Reset
    private void resetScores() {
        localScore = 0;
        visitorScore = 0;
        updateLocalScore();
        updateVisitorScore();
    }

    // Navegar a ScoreActivity
    private void showResults() {
        Intent intent = new Intent(this, ScoreActivity.class);
        intent.putExtra(EXTRA_LOCAL_SCORE, localScore);
        intent.putExtra(EXTRA_VISITOR_SCORE, visitorScore);
        startActivity(intent);
    }
}