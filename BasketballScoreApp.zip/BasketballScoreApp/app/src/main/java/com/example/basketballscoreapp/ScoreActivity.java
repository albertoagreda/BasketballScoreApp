package com.example.basketballscoreapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.basketballscoreapp.databinding.ActivityScoreBinding;

public class ScoreActivity extends AppCompatActivity {

    private ActivityScoreBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializar Data Binding
        binding = ActivityScoreBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtener los marcadores del Intent
        int localScore = getIntent().getIntExtra(MainActivity.EXTRA_LOCAL_SCORE, 0);
        int visitorScore = getIntent().getIntExtra(MainActivity.EXTRA_VISITOR_SCORE, 0);

        // Mostrar el marcador final
        String finalScore = localScore + " - " + visitorScore;
        binding.tvFinalScore.setText(finalScore);

        // Determinar el resultado
        String resultMessage;
        if (localScore > visitorScore) {
            resultMessage = "¡Ganó el equipo Local!";
        } else if (visitorScore > localScore) {
            resultMessage = "¡Ganó el equipo Visitante!";
        } else {
            resultMessage = "¡Empate!";
        }
        binding.tvResult.setText(resultMessage);

        // Botón para volver
        binding.btnBack.setOnClickListener(v -> finish());
    }
}